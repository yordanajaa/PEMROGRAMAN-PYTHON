RATE = 1.1 # (rate) menggunakan huruf besar/kapital
def hitung(x):
    return x * RATE