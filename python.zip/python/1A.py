
# python -m venv .venv

# .\.venv\Scripts\Activate #/


# pip install "requests==2.*"

